function getValue()
{
  var value = document.getElementById('select2').value;
  var value2 = document.getElementById('select4').value;
  var value3 = document.getElementById('select6').value;
  var value4 = document.getElementById('select8').value;
  var value5 = document.getElementById('select10').value;
  var value6 = document.getElementById('select12').value;
  var valuecombined = Number(value) + Number(value2) + Number(value3) + Number(value4) + Number(value5) + Number(value6);
  document.getElementById('renowns').value= valuecombined;
}
