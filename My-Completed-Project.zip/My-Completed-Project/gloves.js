function populate3(s7,s8){
  var s7 = document.getElementById(s7);
  var s8 = document.getElementById(s8);
  s8.innerHTML="";
  if(s7.value == "Grunil"){
    var optionArray = ["¦"
    ,"3¦Grunil"
    ,"6¦Grunil + 1"
    ,"9¦Grunil + 2"
    ,"11¦Grunil + 3"
    ,"13¦Grunil + 4"
    ,"15¦Grunil + 5"
    ,"18¦Grunil + 6"
    ,"21¦Grunil + 7"
    ,"24¦Grunil + 8"
    ,"27¦Grunil + 9"
    ,"30¦Grunil + 10"
    ,"33¦Grunil + 11"
    ,"36¦Grunil + 12"
    ,"39¦Grunil + 13"
    ,"42¦Grunil + 14"
    ,"45¦Grunil + 15"
    ,"50¦Grunil I"
    ,"55¦Grunil II"
    ,"63¦Grunil III"
    ,"68¦Grunil IV"
    ,"73¦Grunil V"
  ];
}
    else if(s7.value == "Heve"){
      var optionArray = ["¦"
      ,"3¦Heve"
      ,"6¦Heve + 1"
      ,"9¦Heve + 2"
      ,"11¦Heve + 3"
      ,"13¦Heve + 4"
      ,"15¦Heve + 5"
      ,"18¦Heve + 6"
      ,"21¦Heve + 7"
      ,"24¦Heve + 8"
      ,"27¦Heve + 9"
      ,"30¦Heve + 10"
      ,"33¦Heve + 11"
      ,"36¦Heve + 12"
      ,"39¦Heve + 13"
      ,"42¦Heve + 14"
      ,"45¦Heve + 15"
      ,"50¦Heve I"
      ,"55¦Heve II"
      ,"63¦Heve III"
      ,"68¦Heve IV"
      ,"73¦Heve V"
    ];
  }
      else if(s7.value == "Agerian"){
        var optionArray = ["¦"
      ,"3¦Agerian"
      ,"6¦Agerian + 1"
      ,"9¦Agerian + 2"
      ,"11¦Agerian + 3"
      ,"13¦Agerian + 4"
      ,"15¦Agerian + 5"
      ,"18¦Agerian + 6"
      ,"21¦Agerian + 7"
      ,"24¦Agerian + 8"
      ,"27¦Agerian + 9"
      ,"30¦Agerian + 10"
      ,"33¦Agerian + 11"
      ,"36¦Agerian + 12"
      ,"39¦Agerian + 13"
      ,"42¦Agerian + 14"
      ,"45¦Agerian + 15"
      ,"50¦Agerian I"
      ,"55¦Agerian II"
      ,"63¦Agerian III"
      ,"68¦Agerian IV"
      ,"73¦Agerian V"
    ];
  }
      else if(s7.value == "Boss"){
        var optionArray = ["¦"
      ,"3¦Boss"
      ,"6¦Boss + 1"
      ,"9¦Boss + 2"
      ,"11¦Boss + 3"
      ,"13¦Boss + 4"
      ,"15¦Boss + 5"
      ,"18¦Boss + 6"
      ,"21¦Boss + 7"
      ,"24¦Boss + 8"
      ,"27¦Boss + 9"
      ,"30¦Boss + 10"
      ,"33¦Boss + 11"
      ,"36¦Boss + 12"
      ,"39¦Boss + 13"
      ,"42¦Boss + 14"
      ,"45¦Boss + 15"
      ,"50¦Boss I"
      ,"55¦Boss II"
      ,"63¦Boss III"
      ,"68¦Boss IV"
      ,"73¦Boss V"
    ];
  }
    for(var option in optionArray){
        var pair = optionArray[option].split("¦");
        var newOption = document.createElement("option");
        newOption.value = pair[0];
        newOption.innerHTML = pair[1];
        s8.options.add(newOption);

    }
  }
