function populate4(s11,s12){
  var s11 = document.getElementById(s11);
  var s12 = document.getElementById(s12);
  s12.innerHTML="";
  if(s11.value == "Liverto"){
    var optionArray = ["¦"
    ,"3¦Liverto"
    ,"6¦Liverto + 1"
    ,"9¦Liverto + 2"
    ,"11¦Liverto + 3"
    ,"13¦Liverto + 4"
    ,"15¦Liverto + 5"
    ,"18¦Liverto + 6"
    ,"21¦Liverto + 7"
    ,"24¦Liverto + 8"
    ,"27¦Liverto + 9"
    ,"30¦Liverto + 10"
    ,"33¦Liverto + 11"
    ,"36¦Liverto + 12"
    ,"39¦Liverto + 13"
    ,"42¦Liverto + 14"
    ,"45¦Liverto + 15"
    ,"50¦Liverto I"
    ,"55¦Liverto II"
    ,"63¦Liverto III"
    ,"68¦Liverto IV"
    ,"73¦Liverto V"
  ];
}
    else if(s11.value == "Kzarka"){
      var optionArray = ["¦"
      ,"3¦Kzarka"
      ,"6¦Kzarka + 1"
      ,"9¦Kzarka + 2"
      ,"11¦Kzarka + 3"
      ,"13¦Kzarka + 4"
      ,"15¦Kzarka + 5"
      ,"18¦Kzarka + 6"
      ,"21¦Kzarka + 7"
      ,"24¦Kzarka + 8"
      ,"27¦Kzarka + 9"
      ,"30¦Kzarka + 10"
      ,"33¦Kzarka + 11"
      ,"36¦Kzarka + 12"
      ,"39¦Kzarka + 13"
      ,"42¦Kzarka + 14"
      ,"45¦Kzarka + 15"
      ,"50¦Kzarka I"
      ,"55¦Kzarka II"
      ,"63¦Kzarka III"
      ,"68¦Kzarka IV"
      ,"73¦Kzarka V"
    ];
  }
      else if(s11.value == "Cliffs"){
        var optionArray = ["¦"
      ,"3¦Cliffs"
      ,"6¦Cliffs + 1"
      ,"9¦Cliffs + 2"
      ,"11¦Cliffs + 3"
      ,"13¦Cliffs + 4"
      ,"15¦Cliffs + 5"
      ,"18¦Cliffs + 6"
      ,"21¦Cliffs + 7"
      ,"24¦Cliffs + 8"
      ,"27¦Cliffs + 9"
      ,"30¦Cliffs + 10"
      ,"33¦Cliffs + 11"
      ,"36¦Cliffs + 12"
      ,"39¦Cliffs + 13"
      ,"42¦Cliffs + 14"
      ,"45¦Cliffs + 15"
      ,"50¦Cliffs I"
      ,"55¦Cliffs II"
      ,"63¦Cliffs III"
      ,"68¦Cliffs IV"
      ,"73¦Cliffs V"
    ];
  }
      else if(s11.value == "Rosar"){
        var optionArray = ["¦"
      ,"3¦Rosar"
      ,"6¦Rosar + 1"
      ,"9¦Rosar + 2"
      ,"11¦Rosar + 3"
      ,"13¦Rosar + 4"
      ,"15¦Rosar + 5"
      ,"18¦Rosar + 6"
      ,"21¦Rosar + 7"
      ,"24¦Rosar + 8"
      ,"27¦Rosar + 9"
      ,"30¦Rosar + 10"
      ,"33¦Rosar + 11"
      ,"36¦Rosar + 12"
      ,"39¦Rosar + 13"
      ,"42¦Rosar + 14"
      ,"45¦Rosar + 15"
      ,"50¦Rosar I"
      ,"55¦Rosar II"
      ,"63¦Rosar III"
      ,"68¦Rosar IV"
      ,"73¦Rosar V"
    ];
  }
    for(var option in optionArray){
        var pair = optionArray[option].split("¦");
        var newOption = document.createElement("option");
        newOption.value = pair[0];
        newOption.innerHTML = pair[1];
        s12.options.add(newOption);

    }
  }
