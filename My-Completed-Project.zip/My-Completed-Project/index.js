var Peer = require('simple-peer')
var peer = new Peer({
  initiator: location.hash ==='#init',
  trickle: false
})

peer.on('signal', function(data) {
  document.getElementById('id1').value = JSON.stringify(data)
})

document.getElementById('connect').addEventListener('click', function(){
    var id2 = JSON.parse(document.getElementById('id2').value)
      peer.signal(id2)
})

document.getElementById('send').addEventListener('click', function(){
    var userMessage = document.getElementById('userMessage').value
      peer.send(userMessage)
})

peer.on('data', function (data){
  document.getElementById('messages').textContent += data + '\n'

})

document.getElementById('share1').addEventListener('click', function(){
    var share1 = document.getElementById('renowns').value
      peer.send(share1)
})

peer.on('data', function (data){
  document.getElementById('userMesage').textContent += data + '\n'

})
document.getElementById('healing').addEventListener('click', function(){
    var share2 = document.getElementById('healing').value
      peer.send(share2)
})

peer.on('data', function (data){
  document.getElementById('userMesage').textContent += data + '\n'

})
document.getElementById('tank').addEventListener('click', function(){
    var share3 = document.getElementById('tank').value
      peer.send(share3)
})

peer.on('data', function (data){
  document.getElementById('userMesage').textContent += data + '\n'

})
document.getElementById('focus').addEventListener('click', function(){
    var share4 = document.getElementById('focus').value
      peer.send(share4)
})

peer.on('data', function (data){
  document.getElementById('userMesage').textContent += data + '\n'

})
document.getElementById('minions').addEventListener('click', function(){
    var share5 = document.getElementById('minions').value
      peer.send(share5)
})

peer.on('data', function (data){
  document.getElementById('userMesage').textContent += data + '\n'

})
document.getElementById('buggy').addEventListener('click', function(){
    var share6 = document.getElementById('buggy').value
      peer.send(share6)
})

peer.on('data', function (data){
  document.getElementById('userMesage').textContent += data + '\n'

})
